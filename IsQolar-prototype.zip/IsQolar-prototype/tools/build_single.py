"""Builds IsQolar.html: one self-contained file (CSS, fonts, data, JS and the QR library all inlined).
Usage, from the IsQolar-prototype folder:   python3 tools/build_single.py
Needs Node.js (it runs esbuild through npx the first time)."""
import base64, pathlib, re, subprocess, tempfile

root = pathlib.Path(__file__).resolve().parent.parent
src = root / 'source'
bundle = pathlib.Path(tempfile.gettempdir()) / 'isqolar-bundle.js'
subprocess.run(['npx', '--yes', 'esbuild', str(src / 'app.js'), '--bundle', '--format=iife', '--minify', f'--outfile={bundle}'], check=True)

css = ''.join((src / 'css' / f).read_text() for f in ('tokens.css', 'components.css', 'gradient.css', 'screens.css', 'landing.css'))
def font(m):
    return 'url("data:font/woff2;base64,' + base64.b64encode((src / 'css' / m.group(1)).read_bytes()).decode() + '")'
css = re.sub(r'url\("(\.\./fonts/[^"]+)"\)', font, css)
css += "\n:root{color-scheme:light;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}\nhtml{scroll-padding-top:env(safe-area-inset-top,0px)}\n"

html = f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>IsQolar</title>
<style>{css}</style></head>
<body><div id="hub"></div>
<script>window.__PQ_DEMO=true;</script>
<script>{(src / 'js' / 'vendor' / 'qrcode.js').read_text()}</script>
<script>{bundle.read_text()}</script>
</body></html>'''
out = root / 'IsQolar.html'
out.write_text(html)
print('wrote', out, round(out.stat().st_size / 1024), 'KB')
