# IsQolar prototype

A clickable prototype of IsQolar, the first-year enrollment queue for PUP Manila. Students, guardians and staff each get their own screen, and a Now serving board is included. All data is simulated.

## Open it

Double-click **IsQolar.html**. It is one self-contained file: no install, no internet, no server.

Open it in two browser tabs to see the screens react to each other. They share state in the same browser, for example `IsQolar.html#student` in one tab and `IsQolar.html#stall` in the other.

## Demo logins

| Persona | How to get in |
|---|---|
| Student | The join form is prefilled. Permit number `2026-00123-MN-0` is the demo student, Juan, in BSIT |
| Guardian | Same permit number, then the one-time code. No SMS is sent, so the code is shown on screen |
| Staff | Pick a stall (BSIT matches the demo student) and use the PIN `1234` |
| Now serving board | No login. Use the arrows or the dropdown to switch college screens |

Suggested walkthrough: join as the student, sign in as staff on BSIT, press **Call next** until the student's turn (the gold banner appears), then **Mark done**. Open the Guardian screen to watch the same student's progress. Keyboard shortcuts on the staff screen: N call next, D mark done, H hold, U undo.

The landing page has two **Prototype tools**: reset the simulated morning, and simulate network loss (every screen then shows "Not updating").

## What is in it

- **Student:** ticket with live wait, requirements checklist, course live count (bento tiles, curriculum by year), campus guide with a college widget, profile with accessibility settings, English and Filipino.
- **Guardian:** permit number and one-time code sign-in, course slot updates, enrollment steps. Progress only, never the ticket number, QR or permit.
- **Staff:** PIN sign-in, Call next, Mark done, Hold, Recall, Undo, ticket lookup, accessibility notices and text cards.
- **Now serving board:** one screen per college, up to eight stalls in two rows.
- **Accessibility:** vibration patterns, written-communication cards, large text, high contrast, Show to staff mode, read-my-status, screen reader announcements.

## Placeholders and limits

- All numbers come from a simulated morning that runs faster than real time. There is no backend.
- The requirements list, course descriptions and the sample curriculum are placeholders. Replace them with the registrar's and departments' own content.
- The campus guide is schematic and not to scale. Campuses and landmarks come from pup.edu.ph. Which Mabini building holds each college is not published there, so it is marked "to be confirmed".
- Filipino strings are drafts and need a native speaker's review.
- Not built yet: camera ticket scan, printable ticket, real SMS and real guardian sync.
- The look (gradients, gold bands, soft shadows) goes beyond DESIGN-PUP-Enrollment-Queue.md, which bans them. The team should approve this before the pilot.

## Source

Folder `source/` has the editable project. It needs a local server because it loads modules:

    cd source
    python3 -m http.server 8000
    # open http://localhost:8000/        landing page with every persona
    # open http://localhost:8000/student/?demo=1   a single persona on its own page
    # also /guardian/  /staff/  /board/

    source/
    ├─ index.html, app.js      landing page and prototype shell
    ├─ student/ guardian/ staff/ board/   one entry page per persona
    ├─ js/store.js             shared mock store and simulation (swap for the real server)
    ├─ js/views/               student, guardian, stall (staff), board, home
    ├─ js/strings.en.js, strings.fil.js   all UI text
    ├─ css/                    tokens, components, gradient skin, screens, landing
    ├─ data/colleges.json      13 colleges and 57 programs from pup.edu.ph
    ├─ fonts/                  bundled, nothing loads from a CDN
    └─ docs/                   user journey map

## Rebuild the single file

After editing `source/`, run `python3 tools/build_single.py` from this folder (needs Node.js). It rewrites `IsQolar.html`.
